# Thermostat_VHDl
A Digital Thermostat is designed, built, and tested. The programmable device compares the room temperature to a user-specified temperature to control the operations of a furnace. While the device can be programmed to maintain roon temperature at different level during different times of a day, the user can perform a manual override at any time. 
This report includes details about the design, simulation and testing. Documentation such as VHDL codes is also included.
